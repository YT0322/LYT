import bpy

bpy.ops.mesh.separate(type='MATERIAL')

# gather names

names = [o.name for o in bpy.context.selected_objects if len(o.data.vertices) > 200]

# deselect all
bpy.ops.object.select_all(action='DESELECT')


# iterate over named objects
max_len = 0
max_name = ''
for name in names:

     # select the object
    obj = bpy.data.objects[name]
    vertices_len = len(obj.data.vertices)
    if vertices_len > max_len:
        max_len = vertices_len
        max_name = name

for name in names:

     # select the object
    if not(name == max_name): 
        obj = bpy.data.objects[name]    
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.mesh.separate(type='LOOSE')


obj = bpy.data.objects[max_name]
bpy.context.view_layer.objects.active = obj
obj.select_set(True)
        

    # export object with its name as file name
#    txt_dim_x = str(obj.dimensions.x)
#    #print(type(txt_dim_x))
#    stl_path = os.path.join(destination_path, name +'_xdim_' + txt_dim_x +'.stl')
#    if len(obj.data.vertices) > 100:
#        bpy.ops.export_mesh.stl(filepath=stl_path,use_selection=True)
#    obj.select_set(False)