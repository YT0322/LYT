import bpy
import math

class ModalOperator(bpy.types.Operator):
    bl_idname = "object.modal_operator"
    bl_label = "Simple Modal Operator"
    obj1 = bpy.data.objects.get("crown_1")
    loc1 = obj1.original.location.copy()  # 浅拷贝
    my_dict = {}
    obj_gum = bpy.data.meshes.get("lc_UpperJawScan")
    loc2 = 0
    r = 10
    min = 9999

    def __init__(self):
        print("Start")

    def __del__(self):
        print("End")

    def distance(self , temp):
        res = math.sqrt(
            math.pow(
                temp.co.x -
                self.loc1.x,
                2) +
            math.pow(
                temp.co.y -
                self.loc1.y,
                2) +
            math.pow(
                temp.co.z -
                self.loc1.z,
                2)
        )
        return res


    def initial(self):
        # 将范围内的牙龈上的点加入my_dict{}字典中
        for i in self.obj_gum.vertices:
            # 先排除一部分点
            if (i.co.x >= self.r and i.co.y >= self.r and i.co.z >= self.r):
                continue

            result = self.distance(i)

            if (self.r >= result):
                # print(i.co)
                # 将符合条件的向量写入字典 做key
                self.my_dict[i] = self.distance(i)
        # 牙龈上的点到中点的最短距离
        for value in self.my_dict.values():
            if (self.min > value):
                self.min = value

    def execute(self, context):
        context.object.location.x = self.value_x / 100.0 - 39
        context.object.location.y = self.value_y / 100.0 + 7
        loc2 = context.object.original.location
        self.initial()
        #移动操作
        mov = loc2 - self.loc1
        for key, value in self.my_dict.items():
            print("before" , key.co)
            key.co += mov * self.r / self.min * (self.r - value) / self.r
            print("after" , key.co)
        return {'FINISHED'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':  # Apply
            self.value_x = event.mouse_x
            self.value_y = event.mouse_y
            self.loc1 = self.obj1.original.location.copy()  # 浅拷
            self.execute(context)
        elif event.type == 'LEFTMOUSE':  # Confirm
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            context.object.location.x = self.init_loc_x
            context.object.location.y = self.init_loc_y
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.init_loc_x = context.object.location.x
        self.init_loc_y = context.object.location.y
        self.value_x = event.mouse_x
        self.value_y = event.mouse_y
        self.execute(context)

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


bpy.utils.register_class(ModalOperator)

# test call
bpy.ops.object.modal_operator('INVOKE_DEFAULT')