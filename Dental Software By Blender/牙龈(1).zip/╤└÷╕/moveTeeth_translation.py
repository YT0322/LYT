import bpy
import math
from math import radians
import mathutils

#距离计算
def distance(temp):
    res = math.sqrt(
        math.pow(
            temp.co.x -
            loc1.x,
            2) +
        math.pow(
            temp.co.y -
            loc1.y,
            2) +
        math.pow(
            temp.co.z -
            loc1.z,
            2)
    )
    return res



obj1 = bpy.data.objects.get("crown_1")
loc1 = obj1.original.location.copy() #浅拷贝
print("obj1:", loc1)

# find all points in the range
obj_gum = bpy.data.meshes.get("lc_UpperJawScan")
# 遍历牙龈上的所有点
# 用字典存储 点 及其对应的weight
my_dict = {}
num = 0
r = 10
for i in obj_gum.vertices:
    # 先排除一部分点
    if (i.co.x >= r and i.co.y >= r and i.co.z >= r):
        continue

    result = distance(i)

    if (r >= result):
        # print(i.co)
        # 将符合条件的向量写入字典 做key
        my_dict[i] = distance(i)
        num+=1
        # my_dict[i] = 1.0 * (math.sin(result))

print("num" , num)
## 输出字典中的内容
#for key, value in my_dict.items():
#    print(key, value)

#牙龈上的点到中点的最短距离
min = 9999
for value in my_dict.values():
    if(min > value):
        min = value

# 牙齿向x轴方向移动一个单位
unit = 1
obj1.location[0] += unit
#
#obj1.rotation_euler[0] += radians(45)
#loc2 = obj1.original.location+mathutils.Vector((0,0,6))
loc2 = obj1.original.location # 现在的位置

# 捕捉牙齿中点的运动方向
mov = loc2 - loc1


# 移动范围内的点
for key, value in my_dict.items():
#    key.co += mov * math.cos(0.7 - value)
    key.co += mov * r/min *(r - value)/r


#平滑表面
bpy.ops.object.shade_smooth()