import bpy
import math

#距离计算
def distance(temp):
    res = math.sqrt(
        math.pow(
            temp.co.x -
            loc.x,
            2) +
        math.pow(
            temp.co.y -
            loc.y,
            2) +
        math.pow(
            temp.co.z -
            loc.z,
            2)
    )
    return res

r = 8
meshes_gum = bpy.data.meshes.get("lc_UpperJawScan_label_gum")
obj_gum = bpy.data.objects.get("lc_UpperJawScan_label_gum")

#将每个牙齿重心设置在几何中点 并将坐标设置在global下
for i in range(4,8):
    obj = bpy.data.objects["crown_" + str(i + 1)]

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")  # 全不选
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='MEDIAN')  # 给每个牙齿设置好重心
    bpy.data.scenes["Scene"].transform_orientation_slots[0].type = "GLOBAL"

bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')#@!!!只能设置一个牙齿

#------------------------创建顶点组------------------------------
for j in range(4,8):
    meshes_teeth = bpy.data.meshes.get("crown_" +str(j+1))
    obj_teeth = bpy.data.objects.get("crown_" +str(j+1))
    loc =  obj_teeth.original.location.copy() #浅拷贝

#    bpy.ops.object.mode_set(mode="EDIT")
    #选中牙龈 因为顶点组要加在牙龈上
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")  # 全不选
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj_gum

    # 新建Vertex Group
    new_vertex_group = bpy.context.active_object.vertex_groups.new(name="Group.00" + str(j+1))


    for i in meshes_gum.vertices:
        # 先排除一部分点
        if (abs(i.co.x - loc.x)> r or abs(i.co.y - loc.y) > r or abs(i.co.z - loc.z) > r):
            continue

        result = distance(i)

        if (r >= result):
            print("i-index" , i.index)
            new_vertex_group.add([i.index] , 1.0, 'ADD')
             #Fill the active vertex group with the current paint weight



#------------------------设置权重------------------------------
#模式转换
bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
bpy.context.object.data.use_paint_mask_vertex = True
bpy.data.meshes["lc_UpperJawScan_label_gum"].use_paint_mask_vertex = True

#所有点权重清零
bpy.ops.object.vertex_group_clean(limit = 1)

#选中所有点
bpy.ops.paint.vert_select_all(action = 'SELECT')

#圈中一部分点 并设置权重
circle_points = []

for point in meshes_gum.vertices:
    bpy.data.scenes["Scene"].tool_settings.unified_paint_settings.weight = 1
    bpy.ops.paint.weight_set()

bpy.ops.object.mode_set(mode="OBJECT")

#------------------------添加修改器------------------------------
for i in range(4,8):
    #选中物体：牙龈
    obj = obj_gum
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")  # 全不选
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

    #权重修改器
    bpy.ops.object.modifier_add(type='VERTEX_WEIGHT_PROXIMITY')
    bpy.context.object.modifiers["VertexWeightProximity"].name = "VertexWeightProximity.00" +str(i+1)

    #Vertex Group
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].vertex_group = "Group.00" + str(i+1)
    #Target Object
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].target = bpy.data.objects["crown_" + str(i+1)]
    #Proximity Mode
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].proximity_mode = 'GEOMETRY'
    #Lowest
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].min_dist = 6.1
    #Highest
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].max_dist = 0
    #Type
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].falloff_type = 'SMOOTH'
    #Global Influence
    bpy.context.object.modifiers["VertexWeightProximity.00" + str(i+1)].mask_constant = 0.75

    #挂钩
    bpy.ops.object.modifier_add(type='HOOK')
    bpy.context.object.modifiers["Hook"].name = "Hook.00" +str(i+1)

    #Object
    bpy.context.object.modifiers["Hook.00" +str(i+1)].object = bpy.data.objects["crown_" +str(i+1)]
    #Vertex Group
    bpy.context.object.modifiers["Hook.00" +str(i+1)].vertex_group = "Group.00" +str(i+1)
    #Type
    bpy.context.object.modifiers["Hook.00" +str(i+1)].falloff_type = 'SMOOTH'

#------------------------设置牙齿移动范围------------------------------
# #在每个牙齿重心建立一个点 设置limit distance
# for i in range(2):
#     obj_teeth = bpy.data.objects.get("crown_" + str(i + 1))
#     loc = obj_teeth.original.location.copy()  # 浅拷贝
#     bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=loc, scale=(1, 1, 1))
#     bpy.ops.object.mode_set(mode="EDIT")
#     bpy.ops.mesh.merge(type='CENTER')
#
#     # 给新建的点命名
#     bpy.ops.object.mode_set(mode="OBJECT")
#     P = bpy.context.object
#     P.name = "Point_" + str(i + 1)
#
#     # 选中对应的牙齿
#     obj = bpy.data.objects["crown_" + str(i + 1)]
#     # 为了选定某个物体操作，所以先不要选择所有物体
#     bpy.ops.object.select_all(action='DESELECT')
#     obj.select_set(True)
#     bpy.context.view_layer.objects.active = obj
#
#     # 设置牙齿移动范围
#     bpy.ops.object.constraint_add(type='LIMIT_DISTANCE')
#     bpy.context.object.constraints["Limit Distance"].target = bpy.data.objects["Point_" + str(i + 1)]
#     bpy.context.object.constraints["Limit Distance"].distance = 1.3

#设置limit location
for i in range(4 , 8):
    # 选中对应的牙齿
    obj = bpy.data.objects["crown_" + str(i + 1)]
    # 为了选定某个物体操作，所以先不要选择所有物体
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.context.object.constraints["Limit Location"].owner_space = 'WORLD'

    bpy.ops.object.constraint_add(type='LIMIT_LOCATION')
    bpy.context.object.constraints["Limit Location"].owner_space = 'CUSTOM'
    bpy.context.object.constraints["Limit Location"].owner_space = 'WORLD'

    loc_x = obj.original.location.copy().x
    loc_y = obj.original.location.copy().y
    loc_z = obj.original.location.copy().z

    bpy.context.object.constraints["Limit Location"].use_min_x = True
    bpy.context.object.constraints["Limit Location"].min_x = loc_x - 1
    bpy.context.object.constraints["Limit Location"].use_min_y = True
    bpy.context.object.constraints["Limit Location"].min_y = loc_y - 1
    bpy.context.object.constraints["Limit Location"].use_min_z = True
    bpy.context.object.constraints["Limit Location"].min_z = loc_z - 0

    bpy.context.object.constraints["Limit Location"].use_max_x = True
    bpy.context.object.constraints["Limit Location"].max_x = loc_x + 1
    bpy.context.object.constraints["Limit Location"].use_max_y = True
    bpy.context.object.constraints["Limit Location"].max_y = loc_y + 1
    bpy.context.object.constraints["Limit Location"].use_max_z = True
    bpy.context.object.constraints["Limit Location"].max_z = loc_z + 1

