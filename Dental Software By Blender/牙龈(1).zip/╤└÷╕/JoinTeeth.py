import bpy

#合并两个物体
bpy.ops.object.join()


