#ifndef _UCC_CTYPE_H
#define _UCC_CTYPE_H

int isalnum(int);
int isalpha(int);
int isdigit(int);
int islower(int);
int isspace(int);
int isupper(int);
int tolower(int);
int toupper(int);

#endif  /* ctype.h */